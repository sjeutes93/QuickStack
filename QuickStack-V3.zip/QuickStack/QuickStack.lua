-- QuickStack: buys a configurable amount at a vendor with Modifier + Left-click,
-- and tracks vendor prices so you can compare them (e.g. reputation discounts).
-- Kauft beim Haendler mit Modifier + Linksklick eine einstellbare Menge und
-- merkt sich Haendlerpreise zum Vergleichen (z. B. Rufrabatte).

local ADDON = "QuickStack"
local MAX_AMOUNT = 20           -- slider range 1..20
local MAX_VENDORS_PER_ITEM = 8  -- price history kept per item
local BUG_URL = "https://github.com/sjeutes93/QuickStack/issues"

----------------------------------------------------------------------
-- Localization: English keys, German overrides (deDE clients)
----------------------------------------------------------------------
local de = {
    ["Items"] = "Items",
    ["Prices"] = "Preise",
    ["Settings"] = "Einstellungen",
    ["Bug Report"] = "Bug melden",
    ["Alt-click an item at a vendor to add it automatically, or drag an item from your bags into the box below. Use the slider to set how many are bought per click."] =
        "Alt-Klick auf einen Gegenstand beim H\195\164ndler f\195\188gt ihn automatisch hinzu, oder zieh einen Gegenstand aus deinen Taschen in das Feld unten. Mit dem Regler stellst du ein, wie viele pro Klick gekauft werden.",
    ["Drop an item here to add it"] = "Gegenstand hier ablegen, um ihn hinzuzuf\195\188gen",
    ["No items yet. Alt + Left-click an item at a vendor or drop one above."] =
        "Noch keine Items. Alt + Linksklick beim H\195\164ndler oder oben einen Gegenstand ablegen.",
    ["Prices are saved automatically whenever you open a vendor (price per item). Differences between vendors can come from reputation discounts."] =
        "Preise werden automatisch gespeichert, sobald du einen H\195\164ndler \195\182ffnest (Preis pro St\195\188ck). Unterschiede zwischen H\195\164ndlern k\195\182nnen von Rufrabatten kommen.",
    ["Only my items"] = "Nur meine Items",
    ["No prices recorded yet. Visit a vendor and they appear here automatically."] =
        "Noch keine Preise gespeichert. Besuche einen H\195\164ndler, dann erscheinen sie hier automatisch.",
    ["Modifier key"] = "Modifier-Taste",
    ["Alt is recommended. Ctrl opens the dressing room and Shift opens the quantity prompt."] =
        "Alt wird empfohlen. Strg \195\182ffnet die Anprobe und Umschalt die Mengenabfrage.",
    ["Add items automatically when bought"] = "Items beim Kauf automatisch hinzuf\195\188gen",
    ["Show price table at vendors"] = "Preistabelle beim H\195\164ndler anzeigen",
    ["Show prices in item tooltips"] = "Preise in Item-Tooltips anzeigen",
    ["Show minimap button"] = "Minimap-Button anzeigen",
    ["Reset minimap button position"] = "Minimap-Button zur\195\188cksetzen",
    ["Clear price data"] = "Preisdaten l\195\182schen",
    ["Price data cleared."] = "Preisdaten gel\195\182scht.",
    ["Unlisted items: a full stack (max. 20) is bought."] =
        "Items ohne Eintrag: Es wird ein voller Stack (max. 20) gekauft.",
    ["Describe the problem"] = "Beschreibe das Problem",
    ["Create report"] = "Bericht erstellen",
    ["Addons cannot send data out of the game. Press Ctrl+C to copy the report, then post it in the comments on the QuickStack project page."] =
        "Addons k\195\182nnen keine Daten aus dem Spiel senden. Dr\195\188cke Strg+C, um den Bericht zu kopieren, und poste ihn in den Kommentaren auf der QuickStack-Projektseite.",
    ["Report page (Ctrl+C to copy):"] = "Meldeseite (Strg+C zum Kopieren):",
    ["Left-click: open menu"] = "Linksklick: Men\195\188 \195\182ffnen",
    ["Drag: move button"] = "Ziehen: Button verschieben",
    ["Not enough gold or vendor stock for %s."] = "Nicht genug Gold oder H\195\164ndlerbestand f\195\188r %s.",
    ["Modifier set to %s + Left-click."] = "Taste gesetzt auf %s + Linksklick.",
    ["QuickStack - Prices"] = "QuickStack - Preise",
    ["QuickStack prices"] = "QuickStack-Preise",
    ["No other vendor known yet"] = "Noch kein anderer H\195\164ndler bekannt",
    ["|cffff6060+%d%% here|r - cheaper at %s: %s"] = "|cffff6060+%d%% hier|r - g\195\188nstiger in %s: %s",
    ["|cff40ff40Best price|r (%d%% cheaper than %s)"] = "|cff40ff40Bester Preis|r (%d%% g\195\188nstiger als %s)",
    ["|cff40ff40Same price|r as elsewhere"] = "|cff40ff40Gleicher Preis|r wie anderswo",
}
local isDE = (GetLocale and GetLocale() == "deDE")
local L = setmetatable({}, { __index = function(_, k) return (isDE and de[k]) or k end })

----------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------
local DB
local menu, RefreshItems, RefreshSettings, RefreshPrices, RefreshPanel
local atMerchant = false

local defaults = {
    modifier = "alt",
    autoAdd = true,
    showMinimap = true,
    showPanel = true,
    showTooltip = true,
    pricesMine = true,
    minimapAngle = 215,
    items = {},
    prices = {},
}

local MODIFIERS = {
    alt   = IsAltKeyDown,
    ctrl  = IsControlKeyDown,
    shift = IsShiftKeyDown,
}

local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"
local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
local CoinString = GetCoinTextureString or (C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString)

local function Print(msg)
    print("|cff33ff99" .. ADDON .. "|r: " .. msg)
end

local function Coins(copper)
    copper = math.max(1, math.floor((copper or 0) + 0.5))
    if CoinString then return CoinString(copper) end
    return copper .. "c"
end

local function GetIcon(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    if GetItemIcon then return GetItemIcon(id) end
end

local function GetName(id, link)
    local name = link and link:match("%[(.-)%]")
    if name then return name end
    local getInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if getInfo then name = getInfo(id) end
    return name or ("Item " .. id)
end

local function AddItem(id, link, amount)
    if DB.items[id] then return DB.items[id], false end
    local entry = { name = GetName(id, link), icon = GetIcon(id), amount = amount or MAX_AMOUNT }
    DB.items[id] = entry
    if RefreshItems and menu and menu:IsShown() then RefreshItems() end
    if RefreshPanel and atMerchant then RefreshPanel() end
    return entry, true
end

----------------------------------------------------------------------
-- Buying
----------------------------------------------------------------------
local function GetItemData(index)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local info = C_MerchantFrame.GetItemInfo(index)
        if not info then return end
        return info.name, info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
    end
    local name, _, price, quantity, numAvailable, _, extendedCost = GetMerchantItemInfo(index)
    return name, price, quantity, numAvailable, extendedCost
end

local function BuyStack(index)
    local name, price, bundleSize, numAvailable, hasExtendedCost = GetItemData(index)
    if not name then return end

    local link = GetMerchantItemLink(index)
    local id = link and tonumber(link:match("item:(%d+)"))
    local maxStack = GetMerchantItemMaxStack(index) or 1
    bundleSize = (bundleSize and bundleSize > 0) and bundleSize or 1

    -- Wanted amount: saved value for this item, otherwise a full stack (max 20)
    local entry = id and DB.items[id]
    if not entry and id and DB.autoAdd then
        entry = AddItem(id, link, math.min(maxStack, MAX_AMOUNT))
    end
    local amount = entry and entry.amount or math.min(maxStack, MAX_AMOUNT)
    amount = math.min(amount, maxStack)

    -- Limit by vendor stock (-1 = unlimited)
    if numAvailable and numAvailable >= 0 then
        amount = math.min(amount, numAvailable * bundleSize)
    end
    -- Limit by gold (only computable for pure gold prices)
    if not hasExtendedCost and price and price > 0 then
        amount = math.min(amount, math.floor(GetMoney() / price) * bundleSize)
    end

    if amount < 1 then
        Print(string.format(L["Not enough gold or vendor stock for %s."], name))
        return
    end
    BuyMerchantItem(index, amount)
end

local function OnItemClick(self, button)
    if button ~= "LeftButton" then return end
    local check = MODIFIERS[DB.modifier]
    if not (check and check()) then return end
    local index = self:GetID()
    if index and index > 0 then BuyStack(index) end
end

local function HookButtons()
    for i = 1, (MERCHANT_ITEMS_PER_PAGE or 10) do
        local btn = _G["MerchantItem" .. i .. "ItemButton"]
        if btn and not btn.quickStackHooked then
            btn:HookScript("OnClick", OnItemClick)
            btn.quickStackHooked = true
        end
    end
end

----------------------------------------------------------------------
-- UI toolkit (native WoW look: dialog frame, panel buttons, slider bars)
----------------------------------------------------------------------
local TPL = BackdropTemplateMixin and "BackdropTemplate" or nil

local DIALOG_BACKDROP = {
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
}
local TOOLTIP_BACKDROP = {
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 },
}
local SLIDER_BACKDROP = {
    bgFile = "Interface\\Buttons\\UI-SliderBar-Background",
    edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
    tile = true, tileSize = 8, edgeSize = 8,
    insets = { left = 3, right = 3, top = 6, bottom = 6 },
}

local function Box(f)
    f:SetBackdrop(TOOLTIP_BACKDROP)
    f:SetBackdropColor(0, 0, 0, 0.55)
    f:SetBackdropBorderColor(0.7, 0.7, 0.7, 1)
end

local function NewFrame(parent, name)
    return CreateFrame("Frame", name, parent, TPL)
end

-- font templates: GameFontNormal (gold), GameFontHighlight (white), GameFontHighlightSmall
local function NewText(parent, template)
    local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    fs:SetJustifyH("LEFT")
    return fs
end

local function NewButton(parent, text, w, h)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, h)
    b:SetText(text)
    return b
end

local function SetSelected(button, selected)
    if selected then button:LockHighlight() else button:UnlockHighlight() end
end

-- Item icon with the classic action-button frame around it
local function NewIcon(parent, size)
    local tex = parent:CreateTexture(nil, "ARTWORK")
    tex:SetSize(size, size)
    tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local border = parent:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetSize(size * 1.8, size * 1.8)
    border:SetPoint("CENTER", tex, "CENTER", 0, -1)
    return tex
end

local function NewSlider(parent, w)
    local s = CreateFrame("Slider", nil, parent, TPL)
    s:SetOrientation("HORIZONTAL")
    s:SetSize(w, 17)
    s:SetBackdrop(SLIDER_BACKDROP)
    s:SetMinMaxValues(1, MAX_AMOUNT)
    s:SetValueStep(1)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    s:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
    local thumb = s:GetThumbTexture()
    if thumb then thumb:SetSize(32, 32) end
    s:EnableMouse(true)
    return s
end

local function NewCheck(parent, label, getter, setter)
    local b = CreateFrame("CheckButton", nil, parent)
    b:SetSize(26, 26)
    b:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
    b:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
    b:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
    b:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    local fs = NewText(b, "GameFontHighlight")
    fs:SetPoint("LEFT", b, "RIGHT", 4, 1)
    fs:SetText(label)
    function b:Refresh()
        self:SetChecked(getter() and true or false)
    end
    b:SetScript("OnClick", function(self)
        setter(self:GetChecked() and true or false)
    end)
    return b
end

local function NewScroll(parent, w, h)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetSize(w, h)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local cur, max = self:GetVerticalScroll(), self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(max, cur - delta * 40)))
    end)
    return scroll
end

local function NewMultiline(parent, w, h)
    local box = NewFrame(parent)
    box:SetSize(w, h)
    Box(box)
    local scroll = NewScroll(box, w - 14, h - 14)
    scroll:SetPoint("TOPLEFT", 7, -7)
    local eb = CreateFrame("EditBox", nil, scroll)
    eb:SetMultiLine(true)
    eb:SetFontObject(ChatFontNormal)
    eb:SetWidth(w - 14)
    eb:SetHeight(h - 14)
    eb:SetAutoFocus(false)
    eb:SetTextInsets(2, 2, 2, 2)
    eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(eb)
    scroll:EnableMouse(true)
    scroll:SetScript("OnMouseDown", function() eb:SetFocus() end)
    return box, eb
end

----------------------------------------------------------------------
-- Price tracking (recorded whenever a vendor window opens)
----------------------------------------------------------------------
local currentVendor
local currentItems = {} -- itemID -> price per single item at the open vendor

local function GetVendorInfo()
    local name = UnitName("npc") or UnitName("target") or "?"
    local guid = UnitGUID("npc")
    local npcID
    if guid and strsplit then npcID = select(6, strsplit("-", guid)) end
    local zone = (GetZoneText and GetZoneText()) or ""
    local key = (npcID and npcID ~= "") and npcID or (name .. "@" .. zone)
    return { key = key, name = name, zone = zone }
end

local function RecordPrice(id, vendor, unitPrice, itemName)
    local t = DB.prices[id]
    if not t then t = {}; DB.prices[id] = t end
    t[vendor.key] = { p = unitPrice, v = vendor.name, z = vendor.zone, t = time(), n = itemName }
    -- keep only the most recent vendors per item
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    while count > MAX_VENDORS_PER_ITEM do
        local oldestKey, oldest
        for key, e in pairs(t) do
            if key ~= vendor.key and (not oldest or e.t < oldest) then oldestKey, oldest = key, e.t end
        end
        if not oldestKey then break end
        t[oldestKey] = nil
        count = count - 1
    end
end

local function ScanMerchant()
    if not atMerchant or not DB then return end
    local vendor = GetVendorInfo()
    currentVendor = vendor
    wipe(currentItems)
    for i = 1, (GetMerchantNumItems() or 0) do
        local name, price, bundle, _, hasExtendedCost = GetItemData(i)
        local link = GetMerchantItemLink(i)
        local id = link and tonumber(link:match("item:(%d+)"))
        if id and name and price and price > 0 and not hasExtendedCost then
            local unit = price / ((bundle and bundle > 0) and bundle or 1)
            currentItems[id] = unit
            RecordPrice(id, vendor, unit, name)
        end
    end
end

local function BestElsewhere(id, hereKey)
    local best
    for key, e in pairs(DB.prices[id] or {}) do
        if key ~= hereKey and (not best or e.p < best.p) then best = e end
    end
    return best
end

local function Where(e)
    return (e.z and e.z ~= "") and e.z or e.v or "?"
end

local function CompareText(id, unit, hereKey)
    local best = BestElsewhere(id, hereKey)
    if not best then return L["No other vendor known yet"] end
    local diff = (unit - best.p) / best.p * 100
    if diff >= 1 then
        return string.format(L["|cffff6060+%d%% here|r - cheaper at %s: %s"],
            math.floor(diff + 0.5), Where(best), Coins(best.p))
    elseif diff <= -1 then
        return string.format(L["|cff40ff40Best price|r (%d%% cheaper than %s)"],
            math.floor(-diff + 0.5), Where(best))
    end
    return L["|cff40ff40Same price|r as elsewhere"]
end

-- Price table next to the vendor window ------------------------------
local panel
local panelRows = {}
local PANEL_W = 320
local PANEL_ROW_H = 36
local MAX_PANEL_ROWS = 12

local function BuildPanel()
    panel = NewFrame(MerchantFrame, "QuickStackPricePanel")
    panel:SetWidth(PANEL_W)
    panel:SetPoint("TOPLEFT", MerchantFrame, "TOPRIGHT", 0, -22)
    panel:SetBackdrop(DIALOG_BACKDROP)
    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 22, -20)
    title:SetText(L["QuickStack - Prices"])
    panel.title = title
end

local function GetPanelRow(i)
    local row = panelRows[i]
    if row then return row end
    row = CreateFrame("Frame", nil, panel)
    row:SetSize(PANEL_W - 40, PANEL_ROW_H - 2)
    row:SetPoint("TOPLEFT", panel, "TOPLEFT", 20, -(44 + (i - 1) * PANEL_ROW_H))
    row.icon = NewIcon(row, 24)
    row.icon:SetPoint("TOPLEFT", 6, -4)
    row.name = NewText(row, "GameFontNormal")
    row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 10, 1)
    row.name:SetWidth(150)
    row.name:SetWordWrap(false)
    row.price = NewText(row, "GameFontHighlight")
    row.price:SetPoint("TOPRIGHT", 0, -2)
    row.price:SetJustifyH("RIGHT")
    row.info = NewText(row, "GameFontHighlightSmall")
    row.info:SetPoint("TOPLEFT", row.icon, "BOTTOMRIGHT", 10, 8)
    row.info:SetWidth(PANEL_W - 40 - 44)
    row.info:SetWordWrap(false)
    panelRows[i] = row
    return row
end

RefreshPanel = function()
    if not DB then return end
    if not (atMerchant and DB.showPanel and MerchantFrame) then
        if panel then panel:Hide() end
        return
    end
    local list = {}
    for id, e in pairs(DB.items) do
        local unit = currentItems[id]
        if unit then list[#list + 1] = { id = id, e = e, unit = unit } end
    end
    table.sort(list, function(a, b) return (a.e.name or "") < (b.e.name or "") end)
    if #list == 0 then
        if panel then panel:Hide() end
        return
    end
    if not panel then BuildPanel() end
    local shown = math.min(#list, MAX_PANEL_ROWS)
    for i = 1, shown do
        local it = list[i]
        local row = GetPanelRow(i)
        row.icon:SetTexture(it.e.icon or QUESTION)
        row.name:SetText(it.e.name or ("Item " .. it.id))
        row.price:SetText(Coins(it.unit))
        row.info:SetText(CompareText(it.id, it.unit, currentVendor and currentVendor.key))
        row:Show()
    end
    for i = shown + 1, #panelRows do panelRows[i]:Hide() end
    panel:SetHeight(44 + shown * PANEL_ROW_H + 18)
    panel:Show()
end

-- Price lines in item tooltips ---------------------------------------
local function AddPriceLines(tooltip, id)
    if not (DB and DB.showTooltip and id) then return end
    local t = DB.prices[id]
    if not t then return end
    local list = {}
    for _, e in pairs(t) do list[#list + 1] = e end
    if #list == 0 then return end
    table.sort(list, function(a, b) return a.p < b.p end)
    tooltip:AddLine(" ")
    tooltip:AddLine(L["QuickStack prices"], 1, 0.82, 0)
    for i = 1, math.min(4, #list) do
        local e = list[i]
        local left = e.v or "?"
        if e.z and e.z ~= "" then left = left .. " (" .. e.z .. ")" end
        local r, g, b = 0.8, 0.8, 0.8
        if i == 1 then r, g, b = 0.25, 1, 0.25 end
        tooltip:AddDoubleLine(left, Coins(e.p), r, g, b, 1, 1, 1)
    end
    tooltip:Show()
end

local function HookTooltips()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
            if tt ~= GameTooltip or not data then return end
            pcall(AddPriceLines, tt, data.id)
        end)
    elseif GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetItem", function(tt)
            local _, link = tt:GetItem()
            local id = link and tonumber(link:match("item:(%d+)"))
            pcall(AddPriceLines, tt, id)
        end)
    end
end

----------------------------------------------------------------------
-- Minimap button (draggable around the minimap edge)
----------------------------------------------------------------------
local mmButton
local atan2 = math.atan2 or math.atan

local function UpdateMinimapPosition()
    if not mmButton then return end
    local angle = math.rad(DB.minimapAngle or 215)
    local radius = (Minimap:GetWidth() / 2) + 5
    mmButton:ClearAllPoints()
    mmButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function UpdateMinimapVisibility()
    if not mmButton then return end
    if DB.showMinimap then mmButton:Show() else mmButton:Hide() end
end

local ToggleMenu -- defined below

local function CreateMinimapButton()
    local b = CreateFrame("Button", "QuickStackMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(19, 19)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    icon:SetPoint("TOPLEFT", 6, -5)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetPoint("TOPLEFT")

    local function OnUpdate()
        local mx, my = Minimap:GetCenter()
        local scale = Minimap:GetEffectiveScale()
        local cx, cy = GetCursorPosition()
        cx, cy = cx / scale, cy / scale
        DB.minimapAngle = math.deg(atan2(cy - my, cx - mx))
        UpdateMinimapPosition()
    end
    b:SetScript("OnDragStart", function(self)
        GameTooltip:Hide()
        self:SetScript("OnUpdate", OnUpdate)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function() ToggleMenu() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("QuickStack", 1, 0.82, 0)
        GameTooltip:AddLine(L["Left-click: open menu"], 1, 1, 1)
        GameTooltip:AddLine(L["Drag: move button"], 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    mmButton = b
    UpdateMinimapPosition()
    UpdateMinimapVisibility()
end

----------------------------------------------------------------------
-- Menu
----------------------------------------------------------------------
local pages, tabs = {}, {}
local PAGE_W = 412

local function ShowTab(key)
    for k, page in pairs(pages) do
        if k == key then page:Show() else page:Hide() end
    end
    for k, tab in pairs(tabs) do SetSelected(tab, k == key) end
    menu.currentTab = key
    if key == "items" and RefreshItems then RefreshItems() end
    if key == "prices" and RefreshPrices then RefreshPrices() end
    if key == "settings" and RefreshSettings then RefreshSettings() end
end

local function NewDeleteButton(parent)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(24, 24)
    b:SetNormalTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
    b:SetPushedTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Down")
    b:SetHighlightTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Highlight", "ADD")
    return b
end

local function BuildItemsPage(page)
    local ROW_H = 56
    local ROW_GAP = 4
    local rows = {}

    local hint = NewText(page, "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 0, 0)
    hint:SetWidth(PAGE_W)
    hint:SetWordWrap(true)
    hint:SetText(L["Alt-click an item at a vendor to add it automatically, or drag an item from your bags into the box below. Use the slider to set how many are bought per click."])

    local drop = CreateFrame("Button", nil, page, TPL)
    drop:SetSize(PAGE_W, 34)
    drop:SetPoint("TOPLEFT", 0, -50)
    Box(drop)
    local plus = drop:CreateTexture(nil, "ARTWORK")
    plus:SetTexture("Interface\\Buttons\\UI-PlusButton-Up")
    plus:SetSize(20, 20)
    local dropText = NewText(drop, "GameFontNormal")
    dropText:SetPoint("CENTER", 12, 0)
    dropText:SetText(L["Drop an item here to add it"])
    plus:SetPoint("RIGHT", dropText, "LEFT", -6, 0)
    drop:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    local function AddFromCursor()
        local kind, id, link = GetCursorInfo()
        if kind == "item" and id then
            AddItem(id, link)
            ClearCursor()
            RefreshItems()
        end
    end
    drop:SetScript("OnReceiveDrag", AddFromCursor)
    drop:SetScript("OnClick", AddFromCursor)

    local scroll = NewScroll(page, PAGE_W, 326)
    scroll:SetPoint("TOPLEFT", 0, -92)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(PAGE_W, 1)
    scroll:SetScrollChild(content)

    local empty = NewText(page, "GameFontHighlight")
    empty:SetPoint("TOPLEFT", 6, -104)
    empty:SetWidth(PAGE_W - 12)
    empty:SetWordWrap(true)
    empty:SetText(L["No items yet. Alt + Left-click an item at a vendor or drop one above."])

    local function CreateRow()
        local row = NewFrame(content)
        row:SetSize(PAGE_W - 4, ROW_H)
        Box(row)

        row.icon = NewIcon(row, 32)
        row.icon:SetPoint("TOPLEFT", 12, -9)

        row.name = NewText(row, "GameFontHighlight")
        row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 10, -2)
        row.name:SetWidth(220)
        row.name:SetWordWrap(false)

        row.value = NewText(row, "GameFontNormal")
        row.value:SetPoint("TOPRIGHT", -40, -12)
        row.value:SetJustifyH("RIGHT")

        row.del = NewDeleteButton(row)
        row.del:SetPoint("TOPRIGHT", -8, -8)
        row.del:SetScript("OnClick", function()
            if row.itemID then
                DB.items[row.itemID] = nil
                RefreshItems()
                if RefreshPanel then RefreshPanel() end
            end
        end)

        row.slider = NewSlider(row, PAGE_W - 4 - 54 - 16)
        row.slider:SetPoint("BOTTOMLEFT", 54, 9)
        row.slider:SetScript("OnValueChanged", function(self, v)
            v = math.floor(v + 0.5)
            row.value:SetText("x" .. v)
            local e = row.itemID and DB.items[row.itemID]
            if e then e.amount = v end
        end)
        return row
    end

    RefreshItems = function()
        local list = {}
        for id, e in pairs(DB.items) do list[#list + 1] = { id = id, e = e } end
        table.sort(list, function(a, b) return (a.e.name or "") < (b.e.name or "") end)

        for i, it in ipairs(list) do
            local row = rows[i]
            if not row then row = CreateRow(); rows[i] = row end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * (ROW_H + ROW_GAP))
            row.itemID = nil -- avoid writing the slider update to the previous item
            local amount = math.max(1, math.min(MAX_AMOUNT, it.e.amount or MAX_AMOUNT))
            row.icon:SetTexture(it.e.icon or QUESTION)
            row.name:SetText(it.e.name or ("Item " .. it.id))
            row.slider:SetValue(amount)
            row.value:SetText("x" .. amount)
            row.itemID = it.id
            row:Show()
        end
        for i = #list + 1, #rows do rows[i]:Hide() end
        content:SetHeight(math.max(1, #list * (ROW_H + ROW_GAP)))
        if #list == 0 then empty:Show() else empty:Hide() end
    end
end

local function BuildPricesPage(page)
    local MAX_LINES = 4
    local LINE_H = 14
    local rows = {}

    local hint = NewText(page, "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 0, 0)
    hint:SetWidth(PAGE_W)
    hint:SetWordWrap(true)
    hint:SetText(L["Prices are saved automatically whenever you open a vendor (price per item). Differences between vendors can come from reputation discounts."])

    local only = NewCheck(page, L["Only my items"],
        function() return DB.pricesMine end,
        function(v) DB.pricesMine = v; RefreshPrices() end)
    only:SetPoint("TOPLEFT", 0, -44)
    page.onlyCheck = only

    local scroll = NewScroll(page, PAGE_W, 336)
    scroll:SetPoint("TOPLEFT", 0, -78)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(PAGE_W, 1)
    scroll:SetScrollChild(content)

    local empty = NewText(page, "GameFontHighlight")
    empty:SetPoint("TOPLEFT", 6, -92)
    empty:SetWidth(PAGE_W - 12)
    empty:SetWordWrap(true)
    empty:SetText(L["No prices recorded yet. Visit a vendor and they appear here automatically."])

    local function CreateRow()
        local row = NewFrame(content)
        row:SetWidth(PAGE_W - 4)
        Box(row)
        row.icon = NewIcon(row, 28)
        row.icon:SetPoint("TOPLEFT", 12, -8)
        row.name = NewText(row, "GameFontNormal")
        row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 10, -1)
        row.name:SetWidth(210)
        row.name:SetWordWrap(false)
        row.best = NewText(row, "GameFontHighlight")
        row.best:SetPoint("TOPRIGHT", -12, -12)
        row.best:SetJustifyH("RIGHT")
        row.left, row.right = {}, {}
        for i = 1, MAX_LINES do
            local l = NewText(row, "GameFontHighlightSmall")
            l:SetPoint("TOPLEFT", 52, -(34 + (i - 1) * LINE_H))
            l:SetWidth(220)
            l:SetWordWrap(false)
            local r = NewText(row, "GameFontHighlightSmall")
            r:SetPoint("TOPRIGHT", -12, -(34 + (i - 1) * LINE_H))
            r:SetJustifyH("RIGHT")
            row.left[i], row.right[i] = l, r
        end
        return row
    end

    RefreshPrices = function()
        local list = {}
        for id, t in pairs(DB.prices) do
            if not DB.pricesMine or DB.items[id] then
                local vendors = {}
                for _, e in pairs(t) do vendors[#vendors + 1] = e end
                if #vendors > 0 then
                    table.sort(vendors, function(a, b) return a.p < b.p end)
                    local name = (DB.items[id] and DB.items[id].name) or vendors[1].n or ("Item " .. id)
                    list[#list + 1] = { id = id, name = name, vendors = vendors }
                end
            end
        end
        table.sort(list, function(a, b) return a.name < b.name end)

        local y = 0
        for i, it in ipairs(list) do
            local row = rows[i]
            if not row then row = CreateRow(); rows[i] = row end
            local n = math.min(MAX_LINES, #it.vendors)
            local h = 38 + n * LINE_H + 6
            row:SetHeight(h)
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -y)
            row.icon:SetTexture((DB.items[it.id] and DB.items[it.id].icon) or GetIcon(it.id) or QUESTION)
            row.name:SetText(it.name)
            local best = it.vendors[1]
            row.best:SetText(Coins(best.p))
            for li = 1, MAX_LINES do
                local e = it.vendors[li]
                if li <= n and e then
                    local left = e.v or "?"
                    if e.z and e.z ~= "" then left = left .. " (" .. e.z .. ")" end
                    local right = Coins(e.p)
                    if li == 1 then
                        left = "|cff40ff40" .. left .. "|r"
                    else
                        local pct = math.floor((e.p - best.p) / best.p * 100 + 0.5)
                        if pct >= 1 then right = right .. " |cffff6060+" .. pct .. "%|r" end
                    end
                    row.left[li]:SetText(left)
                    row.right[li]:SetText(right)
                    row.left[li]:Show()
                    row.right[li]:Show()
                else
                    row.left[li]:Hide()
                    row.right[li]:Hide()
                end
            end
            row:Show()
            y = y + h + 4
        end
        for i = #list + 1, #rows do rows[i]:Hide() end
        content:SetHeight(math.max(1, y))
        if #list == 0 then empty:Show() else empty:Hide() end
        page.onlyCheck:Refresh()
    end
end

local function BuildSettingsPage(page)
    local label = NewText(page, "GameFontNormal")
    label:SetPoint("TOPLEFT", 0, 0)
    label:SetText(L["Modifier key"])

    local modButtons = {}
    local x = 0
    for _, key in ipairs({ "alt", "ctrl", "shift" }) do
        local b = NewButton(page, key:sub(1, 1):upper() .. key:sub(2), 90, 24)
        b:SetPoint("TOPLEFT", x, -22)
        b:SetScript("OnClick", function()
            DB.modifier = key
            RefreshSettings()
        end)
        modButtons[key] = b
        x = x + 96
    end

    local note = NewText(page, "GameFontHighlightSmall")
    note:SetPoint("TOPLEFT", 0, -56)
    note:SetWidth(PAGE_W)
    note:SetWordWrap(true)
    note:SetText(L["Alt is recommended. Ctrl opens the dressing room and Shift opens the quantity prompt."])

    local c1 = NewCheck(page, L["Add items automatically when bought"],
        function() return DB.autoAdd end, function(v) DB.autoAdd = v end)
    c1:SetPoint("TOPLEFT", 0, -92)

    local c2 = NewCheck(page, L["Show price table at vendors"],
        function() return DB.showPanel end,
        function(v) DB.showPanel = v; RefreshPanel() end)
    c2:SetPoint("TOPLEFT", 0, -122)

    local c3 = NewCheck(page, L["Show prices in item tooltips"],
        function() return DB.showTooltip end, function(v) DB.showTooltip = v end)
    c3:SetPoint("TOPLEFT", 0, -152)

    local c4 = NewCheck(page, L["Show minimap button"],
        function() return DB.showMinimap end,
        function(v) DB.showMinimap = v; UpdateMinimapVisibility() end)
    c4:SetPoint("TOPLEFT", 0, -182)

    local reset = NewButton(page, L["Reset minimap button position"], 230, 24)
    reset:SetPoint("TOPLEFT", 0, -226)
    reset:SetScript("OnClick", function()
        DB.minimapAngle = defaults.minimapAngle
        UpdateMinimapPosition()
    end)

    local clear = NewButton(page, L["Clear price data"], 230, 24)
    clear:SetPoint("TOPLEFT", 0, -258)
    clear:SetScript("OnClick", function()
        wipe(DB.prices)
        if atMerchant then ScanMerchant() end
        if RefreshPrices then RefreshPrices() end
        RefreshPanel()
        Print(L["Price data cleared."])
    end)

    local info = NewText(page, "GameFontHighlightSmall")
    info:SetPoint("TOPLEFT", 0, -300)
    info:SetWidth(PAGE_W)
    info:SetWordWrap(true)
    info:SetText(L["Unlisted items: a full stack (max. 20) is bought."])

    RefreshSettings = function()
        for key, b in pairs(modButtons) do SetSelected(b, DB.modifier == key) end
        c1:Refresh(); c2:Refresh(); c3:Refresh(); c4:Refresh()
    end
end

local function BuildBugPage(page)
    local label = NewText(page, "GameFontNormal")
    label:SetPoint("TOPLEFT", 0, 0)
    label:SetText(L["Describe the problem"])

    local inputBox, input = NewMultiline(page, PAGE_W, 130)
    inputBox:SetPoint("TOPLEFT", 0, -22)

    local create = NewButton(page, L["Create report"], 150, 24)
    create:SetPoint("TOPLEFT", 0, -160)

    local hint = NewText(page, "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 0, -194)
    hint:SetWidth(PAGE_W)
    hint:SetWordWrap(true)
    hint:SetText(L["Addons cannot send data out of the game. Press Ctrl+C to copy the report, then post it in the comments on the QuickStack project page."])

    local outBox, output = NewMultiline(page, PAGE_W, 110)
    outBox:SetPoint("TOPLEFT", 0, -244)

    if BUG_URL ~= "" then
        local urlLabel = NewText(page, "GameFontNormalSmall")
        urlLabel:SetPoint("TOPLEFT", 0, -364)
        urlLabel:SetText(L["Report page (Ctrl+C to copy):"])
        local url = CreateFrame("EditBox", nil, page, TPL)
        url:SetSize(PAGE_W, 26)
        url:SetPoint("TOPLEFT", 0, -382)
        Box(url)
        url:SetFontObject(ChatFontNormal)
        url:SetAutoFocus(false)
        url:SetTextInsets(8, 8, 0, 0)
        url:SetText(BUG_URL)
        url:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        url:SetScript("OnTextChanged", function(self, user) if user then self:SetText(BUG_URL) end end)
    end

    create:SetScript("OnClick", function()
        local wowVersion, build, _, toc = GetBuildInfo()
        local count = 0
        for _ in pairs(DB.items) do count = count + 1 end
        local text = string.format(
            "QuickStack %s\nWoW %s (build %s, interface %s), locale %s\nModifier: %s, auto-add: %s, listed items: %d\n\nProblem:\n%s",
            (GetMeta and GetMeta(ADDON, "Version")) or "?",
            tostring(wowVersion), tostring(build), tostring(toc), tostring(GetLocale()),
            tostring(DB.modifier), tostring(DB.autoAdd), count, input:GetText() or "")
        output:SetText(text)
        output:SetFocus()
        output:HighlightText()
    end)
end

local function BuildMenu()
    if menu then return end
    menu = NewFrame(UIParent, "QuickStackMenu")
    menu:SetSize(460, 540)
    menu:SetPoint("CENTER")
    menu:SetFrameStrata("DIALOG")
    menu:SetMovable(true)
    menu:EnableMouse(true)
    menu:SetClampedToScreen(true)
    menu:RegisterForDrag("LeftButton")
    menu:SetScript("OnDragStart", menu.StartMoving)
    menu:SetScript("OnDragStop", menu.StopMovingOrSizing)
    menu:SetBackdrop(DIALOG_BACKDROP)
    tinsert(UISpecialFrames, "QuickStackMenu")
    menu:Hide()

    -- classic gold header plate with title
    local header = menu:CreateTexture(nil, "ARTWORK")
    header:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
    header:SetSize(300, 64)
    header:SetPoint("TOP", 0, 12)
    local title = menu:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", header, "TOP", 0, -14)
    title:SetText("QuickStack")

    local ver = menu:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    ver:SetPoint("BOTTOMLEFT", 26, 14)
    ver:SetText("v" .. ((GetMeta and GetMeta(ADDON, "Version")) or ""))

    -- close button: hides the menu explicitly and sits above everything else
    local close = CreateFrame("Button", nil, menu, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)
    close:SetFrameLevel(menu:GetFrameLevel() + 20)
    close:SetScript("OnClick", function() menu:Hide() end)

    local tabDefs = {
        { key = "items", label = L["Items"] },
        { key = "prices", label = L["Prices"] },
        { key = "settings", label = L["Settings"] },
        { key = "bug", label = L["Bug Report"] },
    }
    for i, def in ipairs(tabDefs) do
        local t = NewButton(menu, def.label, 100, 24)
        t:SetPoint("TOPLEFT", 24 + (i - 1) * 104, -56)
        t:SetScript("OnClick", function() ShowTab(def.key) end)
        tabs[def.key] = t

        local page = CreateFrame("Frame", nil, menu)
        page:SetPoint("TOPLEFT", 24, -92)
        page:SetPoint("BOTTOMRIGHT", -24, 28)
        page:Hide()
        pages[def.key] = page
    end

    BuildItemsPage(pages.items)
    BuildPricesPage(pages.prices)
    BuildSettingsPage(pages.settings)
    BuildBugPage(pages.bug)
end

ToggleMenu = function()
    BuildMenu()
    if menu:IsShown() then
        menu:Hide()
    else
        menu:Show()
        ShowTab(menu.currentTab or "items")
    end
end

----------------------------------------------------------------------
-- Events & slash command
----------------------------------------------------------------------
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("MERCHANT_SHOW")
frame:RegisterEvent("MERCHANT_UPDATE")
frame:RegisterEvent("MERCHANT_CLOSED")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        QuickStackDB = QuickStackDB or {}
        DB = QuickStackDB
        for k, v in pairs(defaults) do
            if DB[k] == nil then
                if type(v) == "table" then DB[k] = {} else DB[k] = v end
            end
        end
        if not MODIFIERS[DB.modifier] then DB.modifier = "alt" end
        CreateMinimapButton()
        HookTooltips()
    elseif event == "MERCHANT_SHOW" then
        atMerchant = true
        HookButtons()
        ScanMerchant()
        RefreshPanel()
        if menu and menu:IsShown() and menu.currentTab == "prices" then RefreshPrices() end
    elseif event == "MERCHANT_UPDATE" then
        if atMerchant then
            ScanMerchant()
            RefreshPanel()
        end
    elseif event == "MERCHANT_CLOSED" then
        atMerchant = false
        currentVendor = nil
        wipe(currentItems)
        if panel then panel:Hide() end
        if menu and menu:IsShown() and menu.currentTab == "prices" then RefreshPrices() end
    end
end)

-- /qs opens the menu; /qs alt | ctrl | shift still sets the modifier directly
SLASH_QUICKSTACK1 = "/qs"
SLASH_QUICKSTACK2 = "/quickstack"
SlashCmdList["QUICKSTACK"] = function(msg)
    msg = (msg or ""):lower():gsub("%s+", "")
    if MODIFIERS[msg] then
        DB.modifier = msg
        if RefreshSettings then RefreshSettings() end
        Print(string.format(L["Modifier set to %s + Left-click."], msg:upper()))
    else
        ToggleMenu()
    end
end
