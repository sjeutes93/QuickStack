-- QuickStack: buys a configurable amount at a vendor with Modifier + Left-click.
-- Kauft beim Haendler mit Modifier + Linksklick eine einstellbare Menge.

local ADDON = "QuickStack"
local MAX_AMOUNT = 20           -- slider range 1..20
local BUG_URL = ""              -- optional: link to your issue tracker / project page

----------------------------------------------------------------------
-- Localization: English keys, German overrides (deDE clients)
----------------------------------------------------------------------
local de = {
    ["Items"] = "Items",
    ["Settings"] = "Einstellungen",
    ["Bug Report"] = "Bug melden",
    ["Alt-click an item at a vendor to add it automatically, or drag an item from your bags into the box below. Use the slider to set how many are bought per click."] =
        "Alt-Klick auf einen Gegenstand beim H\195\164ndler f\195\188gt ihn automatisch hinzu, oder zieh einen Gegenstand aus deinen Taschen in das Feld unten. Mit dem Regler stellst du ein, wie viele pro Klick gekauft werden.",
    ["Drop an item here to add it"] = "Gegenstand hier ablegen, um ihn hinzuzuf\195\188gen",
    ["No items yet. Alt + Left-click an item at a vendor or drop one above."] =
        "Noch keine Items. Alt + Linksklick beim H\195\164ndler oder oben einen Gegenstand ablegen.",
    ["Modifier key"] = "Modifier-Taste",
    ["Alt is recommended. Ctrl opens the dressing room and Shift opens the quantity prompt."] =
        "Alt wird empfohlen. Strg \195\182ffnet die Anprobe und Umschalt die Mengenabfrage.",
    ["Add items automatically when bought"] = "Items beim Kauf automatisch hinzuf\195\188gen",
    ["Show minimap button"] = "Minimap-Button anzeigen",
    ["Reset minimap button position"] = "Minimap-Button zur\195\188cksetzen",
    ["Unlisted items: a full stack (max. 20) is bought."] =
        "Items ohne Eintrag: Es wird ein voller Stack (max. 20) gekauft.",
    ["Describe the problem"] = "Beschreibe das Problem",
    ["Create report"] = "Bericht erstellen",
    ["Addons cannot send data out of the game. Press Ctrl+C to copy the report, then post it in the comments on the QuickStack project page."] =
        "Addons k\195\182nnen keine Daten aus dem Spiel senden. Dr\195\188cke Strg+C, um den Bericht zu kopieren, und poste ihn in den Kommentaren auf der QuickStack-Projektseite.",
    ["Report page (Ctrl+C to copy):"] = "Meldeseite (Strg+C zum Kopieren):",
    ["Left-click: open menu"] = "Linksklick: Men\195\188 \195\182ffnen",
    ["Drag: move button"] = "Ziehen: Button verschieben",
    ["Not enough gold or vendor stock for %s."] = "Nicht genug Gold oder H\195\164ndlerbestand f\195\188r %s.",
    ["Modifier set to %s + Left-click."] = "Taste gesetzt auf %s + Linksklick.",
}
local isDE = (GetLocale and GetLocale() == "deDE")
local L = setmetatable({}, { __index = function(_, k) return (isDE and de[k]) or k end })

----------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------
local DB
local menu, RefreshItems, RefreshSettings

local defaults = {
    modifier = "alt",
    autoAdd = true,
    showMinimap = true,
    minimapAngle = 215,
    items = {},
}

local MODIFIERS = {
    alt   = IsAltKeyDown,
    ctrl  = IsControlKeyDown,
    shift = IsShiftKeyDown,
}

local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"
local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata

local function Print(msg)
    print("|cff33ff99" .. ADDON .. "|r: " .. msg)
end

local function GetIcon(id)
    if C_Item and C_Item.GetItemIconByID then return C_Item.GetItemIconByID(id) end
    if GetItemIcon then return GetItemIcon(id) end
end

local function GetName(id, link)
    local name = link and link:match("%[(.-)%]")
    if name then return name end
    local getInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if getInfo then name = getInfo(id) end
    return name or ("Item " .. id)
end

local function AddItem(id, link, amount)
    if DB.items[id] then return DB.items[id], false end
    local entry = { name = GetName(id, link), icon = GetIcon(id), amount = amount or MAX_AMOUNT }
    DB.items[id] = entry
    if RefreshItems and menu and menu:IsShown() then RefreshItems() end
    return entry, true
end

----------------------------------------------------------------------
-- Buying
----------------------------------------------------------------------
local function GetItemData(index)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local info = C_MerchantFrame.GetItemInfo(index)
        if not info then return end
        return info.name, info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
    end
    local name, _, price, quantity, numAvailable, _, extendedCost = GetMerchantItemInfo(index)
    return name, price, quantity, numAvailable, extendedCost
end

local function BuyStack(index)
    local name, price, bundleSize, numAvailable, hasExtendedCost = GetItemData(index)
    if not name then return end

    local link = GetMerchantItemLink(index)
    local id = link and tonumber(link:match("item:(%d+)"))
    local maxStack = GetMerchantItemMaxStack(index) or 1
    bundleSize = (bundleSize and bundleSize > 0) and bundleSize or 1

    -- Wanted amount: saved value for this item, otherwise a full stack (max 20)
    local entry = id and DB.items[id]
    if not entry and id and DB.autoAdd then
        entry = AddItem(id, link, math.min(maxStack, MAX_AMOUNT))
    end
    local amount = entry and entry.amount or math.min(maxStack, MAX_AMOUNT)
    amount = math.min(amount, maxStack)

    -- Limit by vendor stock (-1 = unlimited)
    if numAvailable and numAvailable >= 0 then
        amount = math.min(amount, numAvailable * bundleSize)
    end
    -- Limit by gold (only computable for pure gold prices)
    if not hasExtendedCost and price and price > 0 then
        amount = math.min(amount, math.floor(GetMoney() / price) * bundleSize)
    end

    if amount < 1 then
        Print(string.format(L["Not enough gold or vendor stock for %s."], name))
        return
    end
    BuyMerchantItem(index, amount)
end

local function OnItemClick(self, button)
    if button ~= "LeftButton" then return end
    local check = MODIFIERS[DB.modifier]
    if not (check and check()) then return end
    local index = self:GetID()
    if index and index > 0 then BuyStack(index) end
end

local function HookButtons()
    for i = 1, (MERCHANT_ITEMS_PER_PAGE or 10) do
        local btn = _G["MerchantItem" .. i .. "ItemButton"]
        if btn and not btn.quickStackHooked then
            btn:HookScript("OnClick", OnItemClick)
            btn.quickStackHooked = true
        end
    end
end

----------------------------------------------------------------------
-- UI toolkit (flat, modern look)
----------------------------------------------------------------------
local FLAT = "Interface\\Buttons\\WHITE8X8"
local TPL = BackdropTemplateMixin and "BackdropTemplate" or nil
local C = {
    bg     = { 0.08, 0.09, 0.12, 0.96 },
    panel  = { 0.14, 0.15, 0.19, 1 },
    border = { 0.24, 0.26, 0.32, 1 },
    accent = { 0.25, 0.72, 0.95, 1 },
    text   = { 0.92, 0.94, 0.97, 1 },
    dim    = { 0.62, 0.66, 0.72, 1 },
}

local function Backdrop(f, bg, border)
    f:SetBackdrop({ bgFile = FLAT, edgeFile = FLAT, edgeSize = 1 })
    f:SetBackdropColor(unpack(bg))
    f:SetBackdropBorderColor(unpack(border))
end

local function NewFrame(parent, name)
    return CreateFrame("Frame", name, parent, TPL)
end

local function NewText(parent, size, color, template)
    local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlight")
    fs:SetTextColor(unpack(color or C.text))
    fs:SetJustifyH("LEFT")
    return fs
end

local function NewButton(parent, text, w, h)
    local b = CreateFrame("Button", nil, parent, TPL)
    b:SetSize(w, h)
    Backdrop(b, C.panel, C.border)
    b.text = NewText(b, 12, C.text)
    b.text:SetPoint("CENTER")
    b.text:SetText(text)
    function b:SetSelected(v)
        self.selected = v
        if v then
            self:SetBackdropColor(0.14, 0.30, 0.38, 1)
            self:SetBackdropBorderColor(unpack(C.accent))
        else
            self:SetBackdropColor(unpack(C.panel))
            self:SetBackdropBorderColor(unpack(C.border))
        end
    end
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(C.accent)) end)
    b:SetScript("OnLeave", function(self)
        if not self.selected then self:SetBackdropBorderColor(unpack(C.border)) end
    end)
    return b
end

local function NewSlider(parent, w)
    local s = CreateFrame("Slider", nil, parent)
    s:SetOrientation("HORIZONTAL")
    s:SetSize(w, 14)
    s:SetMinMaxValues(1, MAX_AMOUNT)
    s:SetValueStep(1)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    local track = s:CreateTexture(nil, "BACKGROUND")
    track:SetColorTexture(0.26, 0.28, 0.35, 1)
    track:SetPoint("LEFT")
    track:SetPoint("RIGHT")
    track:SetHeight(4)
    local thumb = s:CreateTexture(nil, "OVERLAY")
    thumb:SetColorTexture(unpack(C.accent))
    thumb:SetSize(10, 16)
    s:SetThumbTexture(thumb)
    s:EnableMouse(true)
    return s
end

local function NewCheck(parent, label, getter, setter)
    local b = CreateFrame("Button", nil, parent, TPL)
    b:SetSize(20, 20)
    Backdrop(b, C.panel, C.border)
    local mark = b:CreateTexture(nil, "OVERLAY")
    mark:SetColorTexture(unpack(C.accent))
    mark:SetPoint("TOPLEFT", 4, -4)
    mark:SetPoint("BOTTOMRIGHT", -4, 4)
    local fs = NewText(b, 12, C.text)
    fs:SetPoint("LEFT", b, "RIGHT", 10, 0)
    fs:SetText(label)
    function b:Refresh()
        if getter() then mark:Show() else mark:Hide() end
    end
    b:SetScript("OnClick", function(self) setter(not getter()); self:Refresh() end)
    b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(unpack(C.accent)) end)
    b:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(unpack(C.border)) end)
    return b
end

local function NewScroll(parent, w, h)
    local scroll = CreateFrame("ScrollFrame", nil, parent)
    scroll:SetSize(w, h)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", function(self, delta)
        local cur, max = self:GetVerticalScroll(), self:GetVerticalScrollRange()
        self:SetVerticalScroll(math.max(0, math.min(max, cur - delta * 40)))
    end)
    return scroll
end

local function NewMultiline(parent, w, h)
    local box = NewFrame(parent)
    box:SetSize(w, h)
    Backdrop(box, C.panel, C.border)
    local scroll = NewScroll(box, w - 12, h - 12)
    scroll:SetPoint("TOPLEFT", 6, -6)
    local eb = CreateFrame("EditBox", nil, scroll)
    eb:SetMultiLine(true)
    eb:SetFontObject(ChatFontNormal)
    eb:SetWidth(w - 12)
    eb:SetHeight(h - 12)
    eb:SetAutoFocus(false)
    eb:SetTextInsets(2, 2, 2, 2)
    eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(eb)
    scroll:EnableMouse(true)
    scroll:SetScript("OnMouseDown", function() eb:SetFocus() end)
    return box, eb
end

----------------------------------------------------------------------
-- Minimap button (draggable around the minimap edge)
----------------------------------------------------------------------
local mmButton
local atan2 = math.atan2 or math.atan

local function UpdateMinimapPosition()
    if not mmButton then return end
    local angle = math.rad(DB.minimapAngle or 215)
    local radius = (Minimap:GetWidth() / 2) + 5
    mmButton:ClearAllPoints()
    mmButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function UpdateMinimapVisibility()
    if not mmButton then return end
    if DB.showMinimap then mmButton:Show() else mmButton:Hide() end
end

local ToggleMenu -- defined below

local function CreateMinimapButton()
    local b = CreateFrame("Button", "QuickStackMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(17, 17)
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    icon:SetPoint("TOPLEFT", 7, -6)
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetSize(54, 54)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetPoint("TOPLEFT")

    local function OnUpdate()
        local mx, my = Minimap:GetCenter()
        local scale = Minimap:GetEffectiveScale()
        local cx, cy = GetCursorPosition()
        cx, cy = cx / scale, cy / scale
        DB.minimapAngle = math.deg(atan2(cy - my, cx - mx))
        UpdateMinimapPosition()
    end
    b:SetScript("OnDragStart", function(self)
        GameTooltip:Hide()
        self:SetScript("OnUpdate", OnUpdate)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function() ToggleMenu() end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("QuickStack", 1, 0.82, 0)
        GameTooltip:AddLine(L["Left-click: open menu"], 1, 1, 1)
        GameTooltip:AddLine(L["Drag: move button"], 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    mmButton = b
    UpdateMinimapPosition()
    UpdateMinimapVisibility()
end

----------------------------------------------------------------------
-- Menu
----------------------------------------------------------------------
local pages, tabs = {}, {}

local function ShowTab(key)
    for k, page in pairs(pages) do
        if k == key then page:Show() else page:Hide() end
    end
    for k, tab in pairs(tabs) do tab:SetSelected(k == key) end
    menu.currentTab = key
    if key == "items" and RefreshItems then RefreshItems() end
    if key == "settings" and RefreshSettings then RefreshSettings() end
end

local function BuildItemsPage(page)
    local PAGE_W = 408
    local ROW_H = 52
    local rows = {}

    local hint = NewText(page, 12, C.dim)
    hint:SetPoint("TOPLEFT", 0, 0)
    hint:SetWidth(PAGE_W)
    hint:SetWordWrap(true)
    hint:SetText(L["Alt-click an item at a vendor to add it automatically, or drag an item from your bags into the box below. Use the slider to set how many are bought per click."])

    local drop = NewButton(page, L["Drop an item here to add it"], PAGE_W, 34)
    drop:SetPoint("TOPLEFT", 0, -52)
    local function AddFromCursor()
        local kind, id, link = GetCursorInfo()
        if kind == "item" and id then
            AddItem(id, link)
            ClearCursor()
            RefreshItems()
        end
    end
    drop:SetScript("OnReceiveDrag", AddFromCursor)
    drop:SetScript("OnClick", AddFromCursor)

    local scroll = NewScroll(page, PAGE_W, 290)
    scroll:SetPoint("TOPLEFT", 0, -96)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(PAGE_W, 1)
    scroll:SetScrollChild(content)

    local empty = NewText(page, 12, C.dim)
    empty:SetPoint("TOPLEFT", 4, -108)
    empty:SetWidth(PAGE_W - 8)
    empty:SetWordWrap(true)
    empty:SetText(L["No items yet. Alt + Left-click an item at a vendor or drop one above."])

    local function CreateRow()
        local row = NewFrame(content)
        row:SetSize(PAGE_W - 4, ROW_H)
        Backdrop(row, C.panel, C.border)

        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(28, 28)
        row.icon:SetPoint("TOPLEFT", 8, -8)

        row.name = NewText(row, 12, C.text)
        row.name:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 8, -1)
        row.name:SetWidth(250)
        row.name:SetWordWrap(false)

        row.value = NewText(row, 12, C.accent)
        row.value:SetPoint("TOPRIGHT", -42, -9)
        row.value:SetJustifyH("RIGHT")

        row.del = NewButton(row, "x", 22, 22)
        row.del:SetPoint("TOPRIGHT", -8, -7)
        row.del:SetScript("OnClick", function()
            if row.itemID then
                DB.items[row.itemID] = nil
                RefreshItems()
            end
        end)

        row.slider = NewSlider(row, PAGE_W - 4 - 52 - 16)
        row.slider:SetPoint("BOTTOMLEFT", 44, 9)
        row.slider:SetScript("OnValueChanged", function(self, v)
            v = math.floor(v + 0.5)
            row.value:SetText("x" .. v)
            local e = row.itemID and DB.items[row.itemID]
            if e then e.amount = v end
        end)
        return row
    end

    RefreshItems = function()
        local list = {}
        for id, e in pairs(DB.items) do list[#list + 1] = { id = id, e = e } end
        table.sort(list, function(a, b) return (a.e.name or "") < (b.e.name or "") end)

        for i, it in ipairs(list) do
            local row = rows[i]
            if not row then row = CreateRow(); rows[i] = row end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(i - 1) * (ROW_H + 6))
            row.itemID = nil -- avoid writing the slider update to the previous item
            local amount = math.max(1, math.min(MAX_AMOUNT, it.e.amount or MAX_AMOUNT))
            row.icon:SetTexture(it.e.icon or QUESTION)
            row.name:SetText(it.e.name or ("Item " .. it.id))
            row.slider:SetValue(amount)
            row.value:SetText("x" .. amount)
            row.itemID = it.id
            row:Show()
        end
        for i = #list + 1, #rows do rows[i]:Hide() end
        content:SetHeight(math.max(1, #list * (ROW_H + 6)))
        if #list == 0 then empty:Show() else empty:Hide() end
    end
end

local function BuildSettingsPage(page)
    local label = NewText(page, 12, C.dim)
    label:SetPoint("TOPLEFT", 0, 0)
    label:SetText(L["Modifier key"])

    local modButtons = {}
    local x = 0
    for _, key in ipairs({ "alt", "ctrl", "shift" }) do
        local b = NewButton(page, key:sub(1, 1):upper() .. key:sub(2), 90, 28)
        b:SetPoint("TOPLEFT", x, -22)
        b:SetScript("OnClick", function()
            DB.modifier = key
            RefreshSettings()
        end)
        modButtons[key] = b
        x = x + 98
    end

    local note = NewText(page, 11, C.dim)
    note:SetPoint("TOPLEFT", 0, -58)
    note:SetWidth(408)
    note:SetWordWrap(true)
    note:SetText(L["Alt is recommended. Ctrl opens the dressing room and Shift opens the quantity prompt."])

    local c1 = NewCheck(page, L["Add items automatically when bought"],
        function() return DB.autoAdd end, function(v) DB.autoAdd = v end)
    c1:SetPoint("TOPLEFT", 0, -100)

    local c2 = NewCheck(page, L["Show minimap button"],
        function() return DB.showMinimap end,
        function(v) DB.showMinimap = v; UpdateMinimapVisibility() end)
    c2:SetPoint("TOPLEFT", 0, -134)

    local reset = NewButton(page, L["Reset minimap button position"], 230, 28)
    reset:SetPoint("TOPLEFT", 0, -176)
    reset:SetScript("OnClick", function()
        DB.minimapAngle = defaults.minimapAngle
        UpdateMinimapPosition()
    end)

    local info = NewText(page, 11, C.dim)
    info:SetPoint("TOPLEFT", 0, -222)
    info:SetWidth(408)
    info:SetWordWrap(true)
    info:SetText(L["Unlisted items: a full stack (max. 20) is bought."])

    RefreshSettings = function()
        for key, b in pairs(modButtons) do b:SetSelected(DB.modifier == key) end
        c1:Refresh()
        c2:Refresh()
    end
end

local function BuildBugPage(page)
    local label = NewText(page, 12, C.dim)
    label:SetPoint("TOPLEFT", 0, 0)
    label:SetText(L["Describe the problem"])

    local inputBox, input = NewMultiline(page, 408, 130)
    inputBox:SetPoint("TOPLEFT", 0, -22)

    local create = NewButton(page, L["Create report"], 150, 28)
    create:SetPoint("TOPLEFT", 0, -162)

    local hint = NewText(page, 11, C.dim)
    hint:SetPoint("TOPLEFT", 0, -200)
    hint:SetWidth(408)
    hint:SetWordWrap(true)
    hint:SetText(L["Addons cannot send data out of the game. Press Ctrl+C to copy the report, then post it in the comments on the QuickStack project page."])

    local outBox, output = NewMultiline(page, 408, 110)
    outBox:SetPoint("TOPLEFT", 0, -250)

    if BUG_URL ~= "" then
        local urlLabel = NewText(page, 11, C.dim)
        urlLabel:SetPoint("TOPLEFT", 0, -372)
        urlLabel:SetText(L["Report page (Ctrl+C to copy):"])
        local url = CreateFrame("EditBox", nil, page, TPL)
        url:SetSize(408, 24)
        url:SetPoint("TOPLEFT", 0, -388)
        Backdrop(url, C.panel, C.border)
        url:SetFontObject(ChatFontNormal)
        url:SetAutoFocus(false)
        url:SetTextInsets(6, 6, 0, 0)
        url:SetText(BUG_URL)
        url:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        url:SetScript("OnTextChanged", function(self, user) if user then self:SetText(BUG_URL) end end)
    end

    create:SetScript("OnClick", function()
        local wowVersion, build, _, toc = GetBuildInfo()
        local count = 0
        for _ in pairs(DB.items) do count = count + 1 end
        local text = string.format(
            "QuickStack %s\nWoW %s (build %s, interface %s), locale %s\nModifier: %s, auto-add: %s, listed items: %d\n\nProblem:\n%s",
            (GetMeta and GetMeta(ADDON, "Version")) or "?",
            tostring(wowVersion), tostring(build), tostring(toc), tostring(GetLocale()),
            tostring(DB.modifier), tostring(DB.autoAdd), count, input:GetText() or "")
        output:SetText(text)
        output:SetFocus()
        output:HighlightText()
    end)
end

local function BuildMenu()
    if menu then return end
    menu = NewFrame(UIParent, "QuickStackMenu")
    menu:SetSize(440, 500)
    menu:SetPoint("CENTER")
    menu:SetFrameStrata("DIALOG")
    menu:SetMovable(true)
    menu:EnableMouse(true)
    menu:SetClampedToScreen(true)
    menu:RegisterForDrag("LeftButton")
    menu:SetScript("OnDragStart", menu.StartMoving)
    menu:SetScript("OnDragStop", menu.StopMovingOrSizing)
    Backdrop(menu, C.bg, C.border)
    tinsert(UISpecialFrames, "QuickStackMenu")
    menu:Hide()

    local title = NewText(menu, 16, C.accent, "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -14)
    title:SetText("QuickStack")
    local ver = NewText(menu, 11, C.dim, "GameFontNormalSmall")
    ver:SetPoint("LEFT", title, "RIGHT", 8, -1)
    ver:SetText("v" .. ((GetMeta and GetMeta(ADDON, "Version")) or ""))

    local close = NewButton(menu, "x", 24, 24)
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetScript("OnClick", function() menu:Hide() end)

    local tabDefs = {
        { key = "items", label = L["Items"] },
        { key = "settings", label = L["Settings"] },
        { key = "bug", label = L["Bug Report"] },
    }
    for i, def in ipairs(tabDefs) do
        local t = NewButton(menu, def.label, 132, 28)
        t:SetPoint("TOPLEFT", 16 + (i - 1) * 138, -48)
        t:SetScript("OnClick", function() ShowTab(def.key) end)
        tabs[def.key] = t

        local page = CreateFrame("Frame", nil, menu)
        page:SetPoint("TOPLEFT", 16, -90)
        page:SetPoint("BOTTOMRIGHT", -16, 16)
        page:Hide()
        pages[def.key] = page
    end

    BuildItemsPage(pages.items)
    BuildSettingsPage(pages.settings)
    BuildBugPage(pages.bug)
end

ToggleMenu = function()
    BuildMenu()
    if menu:IsShown() then
        menu:Hide()
    else
        menu:Show()
        ShowTab(menu.currentTab or "items")
    end
end

----------------------------------------------------------------------
-- Events & slash command
----------------------------------------------------------------------
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("MERCHANT_SHOW")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        QuickStackDB = QuickStackDB or {}
        DB = QuickStackDB
        for k, v in pairs(defaults) do
            if DB[k] == nil then
                if type(v) == "table" then DB[k] = {} else DB[k] = v end
            end
        end
        if not MODIFIERS[DB.modifier] then DB.modifier = "alt" end
        CreateMinimapButton()
    elseif event == "MERCHANT_SHOW" then
        HookButtons()
    end
end)

-- /qs opens the menu; /qs alt | ctrl | shift still sets the modifier directly
SLASH_QUICKSTACK1 = "/qs"
SLASH_QUICKSTACK2 = "/quickstack"
SlashCmdList["QUICKSTACK"] = function(msg)
    msg = (msg or ""):lower():gsub("%s+", "")
    if MODIFIERS[msg] then
        DB.modifier = msg
        if RefreshSettings then RefreshSettings() end
        Print(string.format(L["Modifier set to %s + Left-click."], msg:upper()))
    else
        ToggleMenu()
    end
end
