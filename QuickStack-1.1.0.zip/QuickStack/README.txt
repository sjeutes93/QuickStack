QUICKSTACK - Anleitung / Guide
==============================

DEUTSCH
-------
Beim Haendler: Alt gedrueckt halten + Linksklick auf einen Gegenstand kauft die
Menge, die du fuer dieses Item eingestellt hast (Standard: ein voller Stack, max. 20).

Menue oeffnen: Klick auf das Muenz-Symbol an der Minimap (am Rand verschiebbar)
oder /qs.
- Reiter "Items": Menge pro Item per Regler (1-20). Items werden beim ersten
  Alt-Klick automatisch hinzugefuegt oder per Drag & Drop aus den Taschen.
  Mit "x" entfernst du ein Item wieder.
- Reiter "Einstellungen": Modifier-Taste (Alt/Strg/Umschalt), automatisches
  Hinzufuegen, Minimap-Button ein/aus bzw. zuruecksetzen.
- Reiter "Bug melden": Problem beschreiben, "Bericht erstellen", mit Strg+C
  kopieren und in den Kommentaren auf der Projektseite posten.

Installation: ueber die CurseForge-App oder den Ordner "QuickStack" nach
World of Warcraft\_retail_\Interface\AddOns\ kopieren (Classic: _classic_ bzw.
_classic_era_).

Probleme? "Inkompatibel/Veraltet": "Veraltete AddOns laden" anhaken. Nichts
passiert: /reload eingeben, Ordner muss exakt "QuickStack" heissen.

ENGLISH
-------
At a vendor, hold Alt + Left-click an item to buy the amount set for that item
(default: a full stack, max. 20).

Open the menu: click the coin icon on the minimap (draggable along its edge) or
type /qs.
- "Items" tab: amount per item via slider (1-20). Items are added on their first
  Alt-click or by dragging them from your bags. Remove with "x".
- "Settings" tab: modifier key (Alt/Ctrl/Shift), auto-add, minimap button.
- "Bug Report" tab: describe the problem, "Create report", copy with Ctrl+C and
  post it in the comments on the project page.

Install via the CurseForge app, or copy the "QuickStack" folder to
World of Warcraft\_retail_\Interface\AddOns\ (Classic: _classic_ / _classic_era_).

Trouble? "Incompatible/Out of date": tick "Load out of date AddOns". Nothing
happens: type /reload and check the folder is named exactly "QuickStack".
