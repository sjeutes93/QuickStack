-- QuickStack: buys a full stack at a vendor with Modifier + Left-click.
-- Kauft beim Haendler mit Modifier + Linksklick einen vollen Stack.

local ADDON = "QuickStack"

----------------------------------------------------------------------
-- Localization (English default, German for deDE clients)
----------------------------------------------------------------------
local L = {
    NOT_ENOUGH = "Not enough gold or vendor stock for %s.",
    MODIFIER_SET = "Modifier set to %s + Left-click.",
    CURRENT = "Current: %s + Left-click. Change with /qs alt, /qs ctrl or /qs shift.",
}
if GetLocale() == "deDE" then
    L.NOT_ENOUGH = "Nicht genug Gold oder Haendlerbestand fuer %s."
    L.MODIFIER_SET = "Taste gesetzt auf %s + Linksklick."
    L.CURRENT = "Aktuell: %s + Linksklick. Aendern mit /qs alt, /qs ctrl oder /qs shift."
end

----------------------------------------------------------------------
local MODIFIERS = {
    alt   = IsAltKeyDown,
    ctrl  = IsControlKeyDown,
    shift = IsShiftKeyDown,
}

local function Print(msg)
    print("|cff33ff99" .. ADDON .. "|r: " .. msg)
end

-- Returns vendor item data (retail table API or classic multi-return)
local function GetItemData(index)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local info = C_MerchantFrame.GetItemInfo(index)
        if not info then return end
        return info.name, info.price, info.stackCount, info.numAvailable, info.hasExtendedCost
    end
    local name, _, price, quantity, numAvailable, _, extendedCost = GetMerchantItemInfo(index)
    return name, price, quantity, numAvailable, extendedCost
end

local function BuyStack(index)
    local name, price, bundleSize, numAvailable, hasExtendedCost = GetItemData(index)
    if not name then return end

    bundleSize = (bundleSize and bundleSize > 0) and bundleSize or 1
    local amount = GetMerchantItemMaxStack(index) or 1

    -- Limit by vendor stock (-1 = unlimited)
    if numAvailable and numAvailable >= 0 then
        amount = math.min(amount, numAvailable * bundleSize)
    end

    -- Limit by gold (only computable for pure gold prices)
    if not hasExtendedCost and price and price > 0 then
        amount = math.min(amount, math.floor(GetMoney() / price) * bundleSize)
    end

    if amount < 1 then
        Print(string.format(L.NOT_ENOUGH, name))
        return
    end

    BuyMerchantItem(index, amount)
end

local function OnItemClick(self, button)
    if button ~= "LeftButton" then return end
    local check = MODIFIERS[QuickStackDB.modifier]
    if not (check and check()) then return end
    local index = self:GetID()
    if index and index > 0 then
        BuyStack(index)
    end
end

local function HookButtons()
    for i = 1, (MERCHANT_ITEMS_PER_PAGE or 10) do
        local btn = _G["MerchantItem" .. i .. "ItemButton"]
        if btn and not btn.quickStackHooked then
            btn:HookScript("OnClick", OnItemClick)
            btn.quickStackHooked = true
        end
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("MERCHANT_SHOW")
frame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON then
        QuickStackDB = QuickStackDB or {}
        if not MODIFIERS[QuickStackDB.modifier] then
            QuickStackDB.modifier = "alt"
        end
    elseif event == "MERCHANT_SHOW" then
        HookButtons()
    end
end)

-- Slash command: /qs alt | ctrl | shift
SLASH_QUICKSTACK1 = "/qs"
SlashCmdList["QUICKSTACK"] = function(msg)
    msg = (msg or ""):lower():gsub("%s+", "")
    if MODIFIERS[msg] then
        QuickStackDB.modifier = msg
        Print(string.format(L.MODIFIER_SET, msg:upper()))
    else
        Print(string.format(L.CURRENT, QuickStackDB.modifier:upper()))
    end
end
