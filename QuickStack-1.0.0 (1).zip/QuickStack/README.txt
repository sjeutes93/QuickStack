QUICKSTACK - Anleitung / Guide
==============================

DEUTSCH
-------
Was macht das Addon?
Beim Haendler kaufst du mit Alt + Linksklick auf einen Gegenstand sofort einen
vollen Stack (z. B. 20 Stueck). Die Stackgroesse wird pro Item automatisch
erkannt. Ist nicht genug Gold oder Bestand da, kauft das Addon so viel wie moeglich.

Installation
1. Ueber die CurseForge-App installieren, ODER das ZIP entpacken und den Ordner
   "QuickStack" nach World of Warcraft\_retail_\Interface\AddOns\ kopieren
   (Classic: _classic_ bzw. _classic_era_).
2. WoW starten. Auf dem Charakterbildschirm unten links "AddOns" pruefen,
   QuickStack muss aktiviert sein.

Benutzung
- Haendler oeffnen, Alt gedrueckt halten und den Gegenstand linksklicken.
- Taste aendern: /qs alt   /qs ctrl   /qs shift
  (Ctrl = Anprobe, Shift = Mengenabfrage - Alt kollidiert mit nichts.)
- /qs zeigt die aktuelle Einstellung an.

Probleme?
- "Inkompatibel/Veraltet": Auf dem Charakterbildschirm bei AddOns den Haken
  "Veraltete AddOns laden" setzen.
- Nichts passiert: /reload eingeben. Pruefen, ob der Ordner genau "QuickStack"
  heisst und direkt QuickStack.toc enthaelt.
- Lua-Fehler: mit /console scriptErrors 1 oder BugSack anzeigen lassen und
  auf der Projektseite melden.
- Items, die mit Marken/Waehrungen bezahlt werden, kann das Addon nicht vorab
  auf Leistbarkeit pruefen; das Spiel meldet, falls es nicht reicht.

ENGLISH
-------
What does it do?
At a vendor, Alt + Left-click on an item instantly buys a full stack. The stack
size is detected per item. If you lack gold or the vendor lacks stock, it buys
as many as possible.

Installation
1. Install via the CurseForge app, OR unzip and copy the "QuickStack" folder to
   World of Warcraft\_retail_\Interface\AddOns\ (Classic: _classic_ / _classic_era_).
2. Make sure QuickStack is enabled in the AddOns list on the character screen.

Usage
- Open a vendor, hold Alt and left-click an item.
- Change the key: /qs alt   /qs ctrl   /qs shift
- /qs shows the current setting.

Troubleshooting
- "Incompatible/Out of date": tick "Load out of date AddOns" on the character
  screen.
- Nothing happens: type /reload and check the folder is named exactly
  "QuickStack" and contains QuickStack.toc directly.
- Lua errors: enable with /console scriptErrors 1 or use BugSack, then report
  them on the project page.
