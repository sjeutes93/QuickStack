## 1.0.0
- Erste Version: Alt + Linksklick kauft einen vollen Stack beim Händler
- Konfigurierbare Taste per /qs
