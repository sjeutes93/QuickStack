# 🪙 QuickStack
### *Stop clicking. Start stacking.* · *Schluss mit Klicken. Her mit den Stacks.*

---

## 🇬🇧 English

Tired of buying items one by one, or fighting the quantity popup every time you restock? **QuickStack** buys exactly the amount **you** choose, with a single click.

> ⚡ **Hold `Alt` + Left-click** an item at any vendor, done.

### ✨ Features
- 🛒 **One-click buying**: Alt + Left-click buys your saved amount instantly
- 🎚️ **Amount per item**: set 1-20 with a slider, e.g. always 15 water. Saved automatically
- 🧭 **Minimap button**: drag it around the minimap edge, click it to open the menu
- ➕ **Easy setup**: items are added on their first Alt-click, or drag them from your bags into the menu
- 💰 **Safe buying**: limited by vendor stock and your gold
- ⌨️ **Your key**: choose Alt, Ctrl or Shift
- 🐞 **Bug report tab**: creates a ready-to-copy report
- 🪶 **Lightweight**: no libraries, no clutter

### ⌨️ Commands
| Command | What it does |
|---|---|
| `/qs` | Opens the QuickStack menu |
| `/qs alt` `/qs ctrl` `/qs shift` | Sets the modifier key |

### 📦 Installation
1. Install via the **CurseForge app**, or copy the `QuickStack` folder to `World of Warcraft/_retail_/Interface/AddOns/` *(Classic: `_classic_` / `_classic_era_`)*
2. Make sure the addon is enabled on the character selection screen
3. Click the coin icon on your minimap, or type `/qs`

### ❓ Troubleshooting
- **"Incompatible" or "Out of date"?** Tick **Load out of date AddOns**
- **Nothing happens?** Type `/reload` and check the folder is named exactly `QuickStack`
- **Found a bug?** Use the **Bug Report** tab in the menu and post the report in the comments

---

## 🇩🇪 Deutsch

Keine Lust, Gegenstände einzeln zu kaufen? **QuickStack** kauft genau die Menge, die **du** einstellst, mit einem Klick.

> ⚡ **`Alt` gedrückt halten + Linksklick** auf einen Gegenstand beim Händler, fertig.

### ✨ Funktionen
- 🛒 **Kauf mit einem Klick**: Alt + Linksklick kauft sofort deine gespeicherte Menge
- 🎚️ **Menge pro Item**: Regler von 1-20, z. B. immer 15 Wasser. Wird automatisch gespeichert
- 🧭 **Minimap-Button**: am Rand der Minimap verschiebbar, Klick öffnet das Menü
- ➕ **Einfache Einrichtung**: Items werden beim ersten Alt-Klick hinzugefügt oder aus den Taschen ins Menü gezogen
- 💰 **Sicher einkaufen**: begrenzt durch Händlerbestand und Gold
- ⌨️ **Deine Taste**: Alt, Strg oder Umschalt
- 🐞 **Bug-Report-Reiter**: erstellt einen kopierfertigen Bericht
- 🪶 **Leichtgewichtig**: keine Bibliotheken

### ⌨️ Befehle
| Befehl | Wirkung |
|---|---|
| `/qs` | Öffnet das QuickStack-Menü |
| `/qs alt` `/qs ctrl` `/qs shift` | Setzt die Modifier-Taste |

### 📦 Installation
1. Über die **CurseForge-App** installieren oder den Ordner `QuickStack` nach `World of Warcraft/_retail_/Interface/AddOns/` kopieren *(Classic: `_classic_` / `_classic_era_`)*
2. Auf dem Charakterbildschirm prüfen, ob das Addon aktiviert ist
3. Auf das Münz-Symbol an der Minimap klicken oder `/qs` eingeben

### ❓ Probleme?
- **„Inkompatibel“ oder „Veraltet“?** **Veraltete AddOns laden** anhaken
- **Nichts passiert?** `/reload` eingeben und prüfen, ob der Ordner exakt `QuickStack` heißt
- **Fehler gefunden?** Reiter **Bug melden** im Menü nutzen und den Bericht in die Kommentare posten
