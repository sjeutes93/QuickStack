## 1.2.0
- New: price table next to the vendor window for the items on your list, with a comparison to the cheapest vendor you have seen (for example a capital city with a reputation discount)
- New: "Prices" tab in the menu with all recorded vendors per item
- New: price lines in item tooltips (can be switched off in the settings)
- Fixed: the X button in the top right corner now reliably closes the menu
- Improved: classic WoW icon frames around items and a native delete icon

## 1.1.0
- New: draggable minimap button that opens the QuickStack menu
- New: menu in the native WoW look (dialog frame, panel buttons, slider bars)
- New: set the purchase amount (1-20) per item with a slider; saved per account
- New: items are added automatically on first Alt-click, or by dragging them from your bags
- New: settings tab (modifier key, auto-add, minimap button)
- New: bug report tab that creates a copyable report
- /qs now opens the menu

## 1.0.0
- Initial release: Alt + Left-click buys a full stack at a vendor
